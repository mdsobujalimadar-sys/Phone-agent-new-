package com.phoneagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Claude {

    @Volatile var onNote: ((String) -> Unit)? = null

    private val SYSTEM = """
You are the brain of an Android phone-control agent. Each step you get the TASK, INSTALLED APPS (sometimes omitted), ACTIONS SO FAR, optionally a SCREENSHOT, and CURRENT SCREEN: a numbered list of UI elements with their center position @x,y in real screen pixels. Decide the next action(s).

Reply with ONLY one JSON object, no other text:
{"thought":"max 12 words","actions":[{"action":"...","id":0,"text":"","app":"","url":"","x":0,"y":0,"message":""}]}

Give 1 action normally. Give up to 3 actions in the list ONLY when they are safe to run back-to-back on the same screen (for example: type into a field, then enter).

Actions:
- open_url (url): open a web link or deep link directly. Fastest way to search or reach a site, e.g. https://www.youtube.com/results?search_query=lofi
- open_app (app): open an app, exact name from INSTALLED APPS
- tap (id): tap a numbered element
- tap_xy (x, y): tap a point. With a screenshot attached use the screenshot's pixel coordinates; otherwise use real pixel coordinates (@x,y) from CURRENT SCREEN. Use when no element fits or tap keeps failing.
- long_press (id)
- type (id, text): set the text of an input field
- enter: press Enter/Search on the keyboard
- scroll_down, scroll_up, swipe_left, swipe_right
- back, home, recents, notifications
- wait: wait for loading
- done (message): the task is finished
- ask_user (message): you need information, a password, an OTP, or the user's confirmation

Rules:
- Use only ids shown in CURRENT SCREEN.
- Prefer open_url and open_app over navigating manually. Use the fewest steps possible.
- If an action FAILED, read the reason and try a different approach. Never repeat a failing action.
- Obey any NOTE in ACTIONS SO FAR.
- Never type passwords, OTP codes or card numbers: use ask_user.
- Before payments, deleting data or sending money use ask_user.
- Do not help with spam, fake accounts, or fake/bulk engagement: use done with a short refusal.
- Write "message" in the same language the user used in TASK.
""".trimIndent()

    class Reply(val actions: List<JSONObject>, val thought: String, val ms: Long)

    fun decide(
        cfg: AgentConfig,
        task: String,
        apps: String,
        history: List<String>,
        screen: String,
        img: String?,
        imgW: Int,
        imgH: Int
    ): Reply {
        val sb = StringBuilder()
        sb.append("TASK: ").append(task)
        if (apps.isNotEmpty()) sb.append("\n\nINSTALLED APPS: ").append(apps)
        sb.append("\n\nACTIONS SO FAR:\n").append(history.takeLast(10).joinToString("\n"))
        if (img != null) {
            sb.append("\n\nSCREENSHOT: attached, ").append(imgW).append("x").append(imgH)
                .append(" pixels (tap_xy coordinates use this size)")
        }
        sb.append("\n\nCURRENT SCREEN:\n").append(screen)
        val user = sb.toString()
        val system = if (cfg.extra.isBlank()) SYSTEM else SYSTEM + "\n\nUSER PREFERENCES:\n" + cfg.extra
        val t0 = System.currentTimeMillis()
        val out = call(cfg, system, user, img)
        val ms = System.currentTimeMillis() - t0
        return parse(out, ms)
    }

    // Connectivity / key / model check with a tiny request. Throws on failure.
    fun ping(cfg: AgentConfig) {
        val out = call(cfg, "You are a connectivity test. Reply with exactly: {\"ok\":true}", "ping", null)
        if (out.isBlank()) throw RuntimeException("Empty reply: the model returned nothing")
    }

    private fun call(cfg: AgentConfig, system: String, user: String, img: String?): String {
        val base = cfg.baseUrl.trim().trimEnd('/')
        return when (cfg.provider) {
            "anthropic" -> callAnthropic(cfg, base, system, user, img)
            "gemini" -> callGemini(cfg, base, system, user, img)
            else -> callOpenAi(cfg, base, system, user, img)
        }
    }

    fun explain(e: Throwable): String {
        val m = e.message ?: ""
        return when (e) {
            is java.net.UnknownHostException -> "No internet or DNS problem (cannot reach " + m + ")"
            is java.net.SocketTimeoutException -> "Timed out: the AI did not answer in time (slow model or weak network)"
            is javax.net.ssl.SSLException -> "Secure connection failed: " + m
            is java.net.ConnectException -> "Cannot connect to the server: " + m
            is org.json.JSONException -> "Unexpected reply format from the AI: " + m.take(120)
            else -> if (m.isBlank()) e.javaClass.simpleName else m
        }
    }

    private fun callAnthropic(cfg: AgentConfig, base: String, system: String, user: String, img: String?): String {
        val content: Any = if (img != null) {
            JSONArray()
                .put(
                    JSONObject().put("type", "image").put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)
                    )
                )
                .put(JSONObject().put("type", "text").put("text", user))
        } else user
        val body = JSONObject()
            .put("model", cfg.model)
            .put("max_tokens", 600)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val resp = post(
            base + "/messages",
            mapOf("x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01"),
            body
        )
        val arr = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        return sb.toString()
    }

    private fun callOpenAi(cfg: AgentConfig, base: String, system: String, user: String, img: String?): String {
        val userContent: Any = if (img != null) {
            JSONArray()
                .put(JSONObject().put("type", "text").put("text", user))
                .put(
                    JSONObject().put("type", "image_url").put(
                        "image_url",
                        JSONObject().put("url", "data:image/jpeg;base64," + img)
                    )
                )
        } else user
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", userContent))
        val body = JSONObject().put("model", cfg.model).put("messages", msgs)
        val resp = post(base + "/chat/completions", mapOf("Authorization" to "Bearer " + cfg.apiKey), body)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content")
    }

    private fun geminiBody(system: String, user: String, img: String?, thinkingOff: Boolean): JSONObject {
        val parts = JSONArray().put(JSONObject().put("text", user))
        if (img != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg").put("data", img)
                )
            )
        }
        val gen = JSONObject()
            .put("maxOutputTokens", 2048)
            .put("temperature", 0.2)
            .put("responseMimeType", "application/json")
        if (thinkingOff) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gen)
    }

    private fun callGemini(cfg: AgentConfig, base: String, system: String, user: String, img: String?): String {
        val url = base + "/models/" + cfg.model + ":generateContent"
        val hdr = mapOf("x-goog-api-key" to cfg.apiKey)
        val flash = cfg.model.contains("flash", true) || cfg.model.contains("lite", true)
        // Flash models answer much faster with "thinking" switched off. Fall back if the model refuses that.
        val resp = if (flash) {
            try {
                post(url, hdr, geminiBody(system, user, img, true))
            } catch (e: RuntimeException) {
                if ((e.message ?: "").startsWith("HTTP 400")) {
                    post(url, hdr, geminiBody(system, user, img, false))
                } else throw e
            }
        } else {
            post(url, hdr, geminiBody(system, user, img, false))
        }
        val ps = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return sb.toString()
    }

    private fun parse(out: String, ms: Long): Reply {
        val s = out.indexOf('{')
        val e = out.lastIndexOf('}')
        if (s < 0 || e < s) throw RuntimeException("The AI did not return JSON: " + out.take(120))
        val o = JSONObject(out.substring(s, e + 1))
        val list = ArrayList<JSONObject>()
        val arr = o.optJSONArray("actions")
        if (arr != null) {
            for (i in 0 until minOf(arr.length(), 3)) {
                val x = arr.optJSONObject(i)
                if (x != null) list.add(x)
            }
        } else if (o.has("action")) {
            list.add(o)
        }
        if (list.isEmpty()) throw RuntimeException("The AI reply had no action: " + out.take(120))
        return Reply(list, o.optString("thought"), ms)
    }

    private fun hint(code: Int): String = when (code) {
        401, 403 -> "HTTP " + code + ": API key invalid or not allowed"
        404 -> "HTTP 404: wrong model name or Base URL"
        429 -> "HTTP 429: rate limit or quota reached"
        400 -> "HTTP 400: bad request (check the model name)"
        else -> "HTTP " + code
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        var lastErr = ""
        for (attempt in 1..2) {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("content-type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code in 200..299) return text
            lastErr = hint(code) + " | " + text.take(160)
            if ((code == 429 || code >= 500) && attempt == 1) {
                onNote?.invoke(hint(code) + " - retrying in 3s")
                Thread.sleep(3000)
                continue
            }
            break
        }
        throw RuntimeException(lastErr)
    }
}
