package com.phoneagent

const val K_INFO = 0
const val K_STEP = 1
const val K_ACT = 2
const val K_OK = 3
const val K_ERR = 4
const val K_WARN = 5
const val K_TIME = 6

class LogEntry(val kind: Int, val text: String)

class AgentConfig(
    val provider: String,
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    val allowRisky: Boolean,
    val maxSteps: Int,
    val speed: Int,
    val vision: Boolean,
    val extra: String
)

// 12.3s style formatting without locale surprises
fun fmtMs(ms: Long): String {
    val t = (ms + 50) / 100
    return "" + (t / 10) + "." + (t % 10) + "s"
}

// Live numbers for the running task, read by the UI ticker
object Live {
    @Volatile var step = 0
    @Volatile var maxSteps = 0
    @Volatile var phase = "Idle"
    @Volatile var phaseSince = 0L
    @Volatile var startedAt = 0L
    @Volatile var endedAt = 0L
    @Volatile var aiMs = 0L
    @Volatile var actMs = 0L
    @Volatile var waitMs = 0L
    @Volatile var shotMs = 0L
    @Volatile var fails = 0
    @Volatile var warns = 0
    @Volatile var lastProblem = ""

    fun reset(max: Int) {
        step = 0
        maxSteps = max
        phase = "Starting"
        startedAt = System.currentTimeMillis()
        phaseSince = startedAt
        endedAt = 0L
        aiMs = 0L
        actMs = 0L
        waitMs = 0L
        shotMs = 0L
        fails = 0
        warns = 0
        lastProblem = ""
    }

    fun markPhase(p: String) {
        phase = p
        phaseSince = System.currentTimeMillis()
    }
}

// Is the AI API alive? Updated by "Test API" and by every call the agent makes
object ApiStatus {
    @Volatile var state = 0      // 0 unknown, 1 active, 2 inactive
    @Volatile var detail = ""
    @Volatile var lastMs = 0L
    @Volatile var totalMs = 0L
    @Volatile var calls = 0
    @Volatile var label = ""

    fun ok(ms: Long, lbl: String) {
        state = 1
        detail = ""
        lastMs = ms
        totalMs += ms
        calls++
        label = lbl
    }

    fun fail(why: String, lbl: String) {
        state = 2
        detail = why
        label = lbl
    }

    fun reset() {
        state = 0
        detail = ""
        lastMs = 0L
        totalMs = 0L
        calls = 0
        label = ""
    }

    fun avg(): Long = if (calls == 0) 0L else totalMs / calls
}
