package com.phoneagent

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    // ---- palette
    private val BG = Color.parseColor("#0E1014")
    private val CARD = Color.parseColor("#171A21")
    private val FIELD = Color.parseColor("#20242E")
    private val BORDER = Color.parseColor("#262B36")
    private val ACCENT = Color.parseColor("#6F82FF")
    private val GREEN = Color.parseColor("#2EB872")
    private val RED = Color.parseColor("#E5484D")
    private val AMBER = Color.parseColor("#FFB454")
    private val TEXT = Color.parseColor("#E9EAF0")
    private val MUTED = Color.parseColor("#8A90A2")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---- providers
    private val names = listOf(
        "Anthropic (Claude)", "OpenAI", "Google Gemini", "DeepSeek", "Groq", "OpenRouter", "Custom (OpenAI-compatible)"
    )
    private val protocols = listOf("anthropic", "openai", "gemini", "openai", "openai", "openai", "openai")
    private val urls = listOf(
        "https://api.anthropic.com/v1",
        "https://api.openai.com/v1",
        "https://generativelanguage.googleapis.com/v1beta",
        "https://api.deepseek.com/v1",
        "https://api.groq.com/openai/v1",
        "https://openrouter.ai/api/v1",
        ""
    )
    private val suggestions = listOf(
        listOf("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"),
        listOf("gpt-4o", "gpt-4o-mini"),
        listOf("gemini-flash-latest", "gemini-pro-latest", "gemini-2.0-flash"),
        listOf("deepseek-chat"),
        listOf("llama-3.3-70b-versatile"),
        listOf("openrouter/auto"),
        listOf<String>()
    )
    private val examples = listOf(
        "Open YouTube and search for lo-fi music",
        "Open Chrome and go to google.com",
        "ইউটিউবে গিয়ে আজকের খবর সার্চ করো"
    )

    private class SavedKey(var name: String, var value: String)

    private lateinit var prefs: SharedPreferences
    private lateinit var cmd: EditText
    private lateinit var url: EditText
    private lateinit var model: EditText
    private lateinit var extra: EditText
    private lateinit var steps: EditText
    private lateinit var providerBtn: TextView
    private lateinit var keyBtn: TextView
    private lateinit var keyHint: TextView
    private lateinit var modelHint: TextView
    private lateinit var chip: TextView
    private lateinit var banner: LinearLayout
    private lateinit var runBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var testBtn: TextView
    private lateinit var apiText: TextView
    private lateinit var phaseTv: TextView
    private lateinit var problemTv: TextView
    private lateinit var segAi: View
    private lateinit var segWait: View
    private lateinit var segAct: View
    private lateinit var legAi: TextView
    private lateinit var legWait: TextView
    private lateinit var legAct: TextView
    private lateinit var logBox: LinearLayout
    private lateinit var emptyHint: TextView
    private lateinit var recentsRow: LinearLayout
    private lateinit var swVision: Switch
    private lateinit var swRisky: Switch
    private lateinit var speedDesc: TextView
    private val speedTabs = ArrayList<TextView>()
    private var keys = ArrayList<SavedKey>()
    private var activeKey = 0
    private var speed = 1
    private var cur = 0
    private var testing = false
    private val tick = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateLive()
            tick.postDelayed(this, 400)
        }
    }

    // ------------------------------------------------------------------ small UI helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun ripple(color: Int, r: Int = 14): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), rounded(color, r), null)

    private fun lpw(w: Int, h: Int, weight: Float = 0f, left: Int = 0, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(left, top, 0, 0)
        return p
    }

    private fun gap(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun field(hint: String, pwd: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(MUTED)
        e.setTextColor(TEXT)
        e.textSize = 15f
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.background = rounded(FIELD, 12, BORDER)
        if (pwd) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        return e
    }

    private fun button(text: String, bg: Int, fg: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(fg)
        t.textSize = 15f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.gravity = Gravity.CENTER
        t.minHeight = dp(48)
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.background = ripple(bg)
        t.isClickable = true
        return t
    }

    private fun card(bg: Int = CARD, stroke: Int = BORDER): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.background = rounded(bg, 18, stroke)
        return c
    }

    private fun seg(color: Int): View {
        val v = View(this)
        v.setBackgroundColor(color)
        v.layoutParams = LinearLayout.LayoutParams(0, MATCH, 0f)
        return v
    }

    private fun setW(v: View, w: Long) {
        val p = v.layoutParams as LinearLayout.LayoutParams
        p.weight = w.toFloat()
        v.layoutParams = p
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------ build UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("agent", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(36))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(label("Phone Agent", 26f, TEXT, true))
        titles.addView(label("AI that operates your phone", 13f, MUTED))
        head.addView(titles, lpw(0, WRAP, 1f))
        chip = label("", 12f, Color.WHITE, true)
        chip.setPadding(dp(12), dp(6), dp(12), dp(6))
        head.addView(chip)
        root.addView(head, lpw(MATCH, WRAP))

        // accessibility banner
        banner = card(Color.parseColor("#2A2312"), Color.parseColor("#5B4A1A"))
        banner.addView(label("Accessibility is off", 15f, Color.parseColor("#FFD36B"), true))
        banner.addView(gap(4))
        banner.addView(label("Phone Agent needs the Accessibility service to see and control the screen.", 13f, MUTED))
        banner.addView(gap(10))
        val enable = button("Enable Accessibility", ACCENT)
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        banner.addView(enable, lpw(MATCH, WRAP))
        root.addView(banner, lpw(MATCH, WRAP, 0f, 0, dp(16)))

        // command card
        val c1 = card()
        c1.addView(label("What should I do?", 15f, TEXT, true))
        c1.addView(gap(8))
        cmd = field("e.g. Open YouTube and search for lo-fi music")
        cmd.minLines = 3
        cmd.gravity = Gravity.TOP
        c1.addView(cmd, lpw(MATCH, WRAP))
        c1.addView(gap(10))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val mic = button("🎤 Voice", FIELD)
        runBtn = button("▶  Run", GREEN)
        stopBtn = button("■  Stop", RED)
        row.addView(mic, lpw(0, WRAP, 1f))
        row.addView(runBtn, lpw(0, WRAP, 1.4f, dp(10)))
        row.addView(stopBtn, lpw(0, WRAP, 1.4f, dp(10)))
        c1.addView(row, lpw(MATCH, WRAP))
        c1.addView(gap(10))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        recentsRow = LinearLayout(this)
        recentsRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(recentsRow)
        c1.addView(hs, lpw(MATCH, WRAP))
        root.addView(c1, lpw(MATCH, WRAP, 0f, 0, dp(12)))

        // live status card
        val cs = card()
        cs.addView(label("Live status", 15f, TEXT, true))
        cs.addView(gap(8))
        phaseTv = label("Idle. Time spent per step will show here.", 13.5f, TEXT)
        cs.addView(phaseTv)
        cs.addView(gap(10))
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = rounded(FIELD, 4)
        segAi = seg(ACCENT)
        segWait = seg(AMBER)
        segAct = seg(GREEN)
        bar.addView(segAi)
        bar.addView(segWait)
        bar.addView(segAct)
        cs.addView(bar, lpw(MATCH, dp(8)))
        cs.addView(gap(6))
        val leg = LinearLayout(this)
        leg.orientation = LinearLayout.HORIZONTAL
        legAi = label("■ AI 0.0s", 12f, ACCENT)
        legWait = label("■ Waiting 0.0s", 12f, AMBER)
        legAct = label("■ Actions 0.0s", 12f, GREEN)
        leg.addView(legAi)
        leg.addView(legWait, lpw(WRAP, WRAP, 0f, dp(14)))
        leg.addView(legAct, lpw(WRAP, WRAP, 0f, dp(14)))
        cs.addView(leg, lpw(MATCH, WRAP))
        problemTv = label("", 12.5f, AMBER)
        problemTv.visibility = View.GONE
        cs.addView(gap(8))
        cs.addView(problemTv)
        root.addView(cs, lpw(MATCH, WRAP, 0f, 0, dp(12)))

        // model card
        val c2 = card()
        c2.addView(label("AI model", 15f, TEXT, true))
        c2.addView(gap(8))
        providerBtn = button("", FIELD)
        providerBtn.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        providerBtn.setOnClickListener { pickProvider() }
        c2.addView(providerBtn, lpw(MATCH, WRAP))
        c2.addView(gap(8))
        val mrow = LinearLayout(this)
        mrow.orientation = LinearLayout.HORIZONTAL
        model = field("Model name")
        val pickModel = button("▾", FIELD)
        pickModel.setOnClickListener { pickModelDialog() }
        mrow.addView(model, lpw(0, WRAP, 1f))
        mrow.addView(pickModel, lpw(dp(52), WRAP, 0f, dp(8)))
        c2.addView(mrow, lpw(MATCH, WRAP))
        modelHint = label("Pro/Opus models are slow and may have no free quota. Flash/Haiku models work much better for the agent.", 12f, AMBER)
        modelHint.visibility = View.GONE
        c2.addView(gap(4))
        c2.addView(modelHint)
        c2.addView(gap(8))
        keyBtn = button("", FIELD)
        keyBtn.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        keyBtn.setOnClickListener { openKeyManager() }
        c2.addView(keyBtn, lpw(MATCH, WRAP))
        keyHint = label("", 12f, MUTED)
        c2.addView(gap(4))
        c2.addView(keyHint)
        c2.addView(gap(10))
        val arow = LinearLayout(this)
        arow.orientation = LinearLayout.HORIZONTAL
        arow.gravity = Gravity.CENTER_VERTICAL
        apiText = label("● Not tested yet", 13.5f, MUTED, true)
        testBtn = button("Test API", ACCENT)
        testBtn.minHeight = dp(40)
        testBtn.textSize = 13f
        arow.addView(apiText, lpw(0, WRAP, 1f))
        arow.addView(testBtn, lpw(WRAP, WRAP, 0f, dp(8)))
        c2.addView(arow, lpw(MATCH, WRAP))
        root.addView(c2, lpw(MATCH, WRAP, 0f, 0, dp(12)))

        // advanced card
        val c3 = card()
        val advHead = label("Advanced  ▾", 15f, TEXT, true)
        val advBody = LinearLayout(this)
        advBody.orientation = LinearLayout.VERTICAL
        advBody.visibility = View.GONE
        advHead.setOnClickListener {
            if (advBody.visibility == View.GONE) {
                advBody.visibility = View.VISIBLE
                advHead.text = "Advanced  ▴"
            } else {
                advBody.visibility = View.GONE
                advHead.text = "Advanced  ▾"
            }
        }
        c3.addView(advHead)

        advBody.addView(gap(12))
        advBody.addView(label("Speed", 13f, MUTED))
        advBody.addView(gap(6))
        val speedRow = LinearLayout(this)
        speedRow.orientation = LinearLayout.HORIZONTAL
        val sn = listOf("Fast", "Normal", "Careful")
        for (i in 0..2) {
            val t = button(sn[i], FIELD)
            t.minHeight = dp(40)
            t.textSize = 13f
            t.setOnClickListener { speed = i; updateSpeed() }
            speedTabs.add(t)
            speedRow.addView(t, lpw(0, WRAP, 1f, if (i == 0) 0 else dp(8)))
        }
        advBody.addView(speedRow, lpw(MATCH, WRAP))
        speedDesc = label("", 12f, MUTED)
        advBody.addView(gap(6))
        advBody.addView(speedDesc)

        advBody.addView(gap(14))
        advBody.addView(label("Max steps per task", 13f, MUTED))
        advBody.addView(gap(6))
        steps = field("30")
        steps.inputType = InputType.TYPE_CLASS_NUMBER
        advBody.addView(steps, lpw(MATCH, WRAP))

        advBody.addView(gap(14))
        swVision = Switch(this)
        swVision.text = "Use screenshots (vision models only)"
        swVision.setTextColor(TEXT)
        advBody.addView(swVision, lpw(MATCH, WRAP))
        advBody.addView(gap(10))
        swRisky = Switch(this)
        swRisky.text = "Allow risky taps (pay / delete)"
        swRisky.setTextColor(TEXT)
        advBody.addView(swRisky, lpw(MATCH, WRAP))

        advBody.addView(gap(14))
        advBody.addView(label("Extra instructions (always applied)", 13f, MUTED))
        advBody.addView(gap(6))
        extra = field("e.g. Always reply in Bengali. Prefer the Chrome app.")
        extra.minLines = 2
        extra.gravity = Gravity.TOP
        advBody.addView(extra, lpw(MATCH, WRAP))

        advBody.addView(gap(14))
        advBody.addView(label("Base URL", 13f, MUTED))
        advBody.addView(gap(6))
        url = field("https://api.example.com/v1")
        advBody.addView(url, lpw(MATCH, WRAP))
        c3.addView(advBody, lpw(MATCH, WRAP))
        root.addView(c3, lpw(MATCH, WRAP, 0f, 0, dp(12)))

        // live log card
        val c4 = card()
        val lh = LinearLayout(this)
        lh.orientation = LinearLayout.HORIZONTAL
        lh.gravity = Gravity.CENTER_VERTICAL
        lh.addView(label("Live activity", 15f, TEXT, true), lpw(0, WRAP, 1f))
        val copy = label("Copy", 13f, ACCENT, true)
        copy.setPadding(dp(10), dp(4), dp(10), dp(4))
        copy.setOnClickListener { copyLog() }
        val clear = label("Clear", 13f, ACCENT, true)
        clear.setPadding(dp(10), dp(4), dp(10), dp(4))
        clear.setOnClickListener {
            AgentService.clearLog()
            logBox.removeAllViews()
            emptyHint.visibility = View.VISIBLE
        }
        lh.addView(copy)
        lh.addView(clear)
        c4.addView(lh, lpw(MATCH, WRAP))
        c4.addView(gap(8))
        emptyHint = label("Nothing yet. Write a task and press Run.", 13f, MUTED)
        c4.addView(emptyHint)
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        c4.addView(logBox, lpw(MATCH, WRAP))
        root.addView(c4, lpw(MATCH, WRAP, 0f, 0, dp(12)))

        root.addView(
            label("Tip: Volume Down or the red floating Stop button stops the agent at any time. If something fails, tap Copy and send me the log.", 12f, MUTED),
            lpw(MATCH, WRAP, 0f, 0, dp(14))
        )

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)

        // ---- restore saved settings
        speed = prefs.getInt("speed", 1)
        steps.setText(prefs.getString("steps", "30"))
        swVision.isChecked = prefs.getBoolean("vision", false)
        swRisky.isChecked = prefs.getBoolean("risky", false)
        extra.setText(prefs.getString("extra", ""))
        cmd.setText(prefs.getString("draft", ""))
        loadProvider(prefs.getInt("provider", 0).coerceIn(0, names.size - 1))
        updateSpeed()
        buildRecents()

        // ---- actions
        mic.setOnClickListener {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            try {
                startActivityForResult(i, 1)
            } catch (e: Exception) {
                toast("Voice input not available on this phone")
            }
        }

        testBtn.setOnClickListener {
            if (testing) return@setOnClickListener
            val k = currentKey()
            val m = model.text.toString().trim()
            val u = url.text.toString().trim()
            if (k.isEmpty()) {
                toast("Add an API key first")
                openKeyManager()
                return@setOnClickListener
            }
            if (m.isEmpty() || u.isEmpty()) {
                toast("Fill the model name and Base URL first")
                return@setOnClickListener
            }
            saveAll()
            testing = true
            testBtn.text = "Testing…"
            val cfg = AgentConfig(protocols[cur], u, k, m, false, 1, 1, false, "")
            val lbl = names[cur] + " · " + m + " · " + (keys.getOrNull(activeKey)?.name ?: "key")
            Thread {
                val t0 = System.currentTimeMillis()
                try {
                    Claude.ping(cfg)
                    ApiStatus.ok(System.currentTimeMillis() - t0, lbl)
                } catch (e: Throwable) {
                    val w = Claude.explain(e)
                    ApiStatus.fail(w + Claude.advise(cfg, w), lbl)
                }
                runOnUiThread {
                    testing = false
                    testBtn.text = "Test API"
                    updateLive()
                }
            }.start()
        }

        runBtn.setOnClickListener {
            val svc = AgentService.instance
            if (svc == null) {
                toast("Turn on Accessibility first")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            val task = cmd.text.toString().trim()
            val k = currentKey()
            val m = model.text.toString().trim()
            val u = url.text.toString().trim()
            if (task.isEmpty()) { toast("Write a task first"); return@setOnClickListener }
            if (k.isEmpty()) {
                toast("Add your API key first")
                openKeyManager()
                return@setOnClickListener
            }
            if (m.isEmpty() || u.isEmpty()) { toast("Model and Base URL are required"); return@setOnClickListener }
            saveAll()
            addRecent(task)
            val maxSteps = (steps.text.toString().toIntOrNull() ?: 30).coerceIn(3, 80)
            val cfg = AgentConfig(
                protocols[cur], u, k, m, swRisky.isChecked, maxSteps, speed, swVision.isChecked,
                extra.text.toString().trim()
            )
            AgentService.clearLog()
            logBox.removeAllViews()
            emptyHint.visibility = View.GONE
            svc.start(task, cfg)
            refreshState()
        }

        stopBtn.setOnClickListener {
            AgentService.running = false
            refreshState()
        }
    }

    // ------------------------------------------------------------------ API key manager
    private fun mask(v: String): String =
        if (v.length <= 10) "••••••" else v.take(4) + "••••••" + v.takeLast(4)

    private fun currentKey(): String = keys.getOrNull(activeKey)?.value ?: ""

    private fun loadKeys(p: Int): ArrayList<SavedKey> {
        val out = ArrayList<SavedKey>()
        val raw = prefs.getString("keys_" + p, null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(SavedKey(o.optString("n"), o.optString("k")))
                }
            } catch (e: Exception) {
            }
        } else {
            // keys saved by older versions of the app
            val legacy = prefs.getString("key_" + p, "") ?: ""
            if (legacy.isNotBlank()) out.add(SavedKey("Key 1", legacy.trim()))
        }
        return out
    }

    private fun persistKeys() {
        val arr = JSONArray()
        for (k in keys) arr.put(JSONObject().put("n", k.name).put("k", k.value))
        prefs.edit()
            .putString("keys_" + cur, arr.toString())
            .putInt("akey_" + cur, activeKey)
            .apply()
    }

    private fun commitKeys() {
        persistKeys()
        ApiStatus.reset()
        refreshKeyRow()
        updateLive()
    }

    private fun refreshKeyRow() {
        val k = keys.getOrNull(activeKey)
        if (k == null) {
            keyBtn.text = "🔑  Add API key"
            keyHint.text = "No key saved for " + names[cur] + ". Tap above to add one."
        } else {
            keyBtn.text = "🔑  " + k.name + "  ·  " + mask(k.value) + "   ▾"
            keyHint.text = keys.size.toString() + " saved key" + (if (keys.size == 1) "" else "s") +
                " for " + names[cur] + ". Tap to switch, edit or add."
        }
    }

    // accepts a bare key, or pulls the key out of pasted text such as a curl command
    private fun extractKey(raw: String): String? {
        var s = raw.trim().trim('"', '\'', '`')
        if (s.startsWith("Bearer ", true)) s = s.substring(7).trim()
        if (s.isEmpty()) return null
        if (s.none { it.isWhitespace() }) return if (s.length >= 8) s else null
        val m = Regex("(AIza[0-9A-Za-z_\\-]{20,}|AQ\\.[0-9A-Za-z_\\-]{20,}|sk-[A-Za-z0-9_\\-]{20,}|gsk_[A-Za-z0-9]{20,}|xai-[A-Za-z0-9]{20,})").find(s)
        return m?.value
    }

    private fun openKeyManager() {
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("API keys · " + names[cur])
            .create()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(box)
        dlg.setView(sv)

        fun render() {
            box.removeAllViews()
            if (keys.isEmpty()) {
                box.addView(label("No saved keys yet. Add one to get started.", 13.5f, MUTED))
                box.addView(gap(12))
            }
            for (i in keys.indices) {
                val k = keys[i]
                val rowCard = card(FIELD, BORDER)
                val inUse = i == activeKey
                rowCard.addView(
                    label(k.name + (if (inUse) "   ● in use" else ""), 15f, if (inUse) GREEN else TEXT, true)
                )
                rowCard.addView(label(mask(k.value), 13f, MUTED))
                rowCard.addView(gap(8))
                val acts = LinearLayout(this)
                acts.orientation = LinearLayout.HORIZONTAL
                val use = button(if (inUse) "In use" else "Use", if (inUse) GREEN else ACCENT)
                use.minHeight = dp(38)
                use.textSize = 13f
                val edit = button("Edit", CARD)
                edit.minHeight = dp(38)
                edit.textSize = 13f
                val del = button("Delete", RED)
                del.minHeight = dp(38)
                del.textSize = 13f
                use.setOnClickListener {
                    activeKey = i
                    commitKeys()
                    render()
                }
                edit.setOnClickListener { editKey(i) { render() } }
                del.setOnClickListener { confirmDelete(i) { render() } }
                acts.addView(use, lpw(0, WRAP, 1f))
                acts.addView(edit, lpw(0, WRAP, 1f, dp(8)))
                acts.addView(del, lpw(0, WRAP, 1f, dp(8)))
                rowCard.addView(acts, lpw(MATCH, WRAP))
                box.addView(rowCard, lpw(MATCH, WRAP, 0f, 0, dp(10)))
            }
            val add = button("+  Add new key", GREEN)
            add.setOnClickListener { editKey(-1) { render() } }
            box.addView(add, lpw(MATCH, WRAP, 0f, 0, dp(4)))
        }

        render()
        dlg.show()
    }

    private fun editKey(index: Int, done: () -> Unit) {
        val existing = keys.getOrNull(index)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))

        val nameF = field("Name (e.g. Personal, Work)")
        nameF.setText(existing?.name ?: ("Key " + (keys.size + 1)))
        val keyF = field("Paste your API key here")
        keyF.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        keyF.setText(existing?.value ?: "")
        val paste = button("Paste from clipboard", FIELD)
        paste.minHeight = dp(40)
        paste.textSize = 13f
        paste.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            if (t.isBlank()) toast("Clipboard is empty") else keyF.setText(t)
        }

        box.addView(label("Name", 13f, MUTED))
        box.addView(gap(6))
        box.addView(nameF, lpw(MATCH, WRAP))
        box.addView(gap(12))
        box.addView(label("API key", 13f, MUTED))
        box.addView(gap(6))
        box.addView(keyF, lpw(MATCH, WRAP))
        box.addView(gap(8))
        box.addView(paste, lpw(MATCH, WRAP))
        val sv = ScrollView(this)
        sv.addView(box)

        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (existing == null) "Add API key" else "Edit API key")
            .setView(sv)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val clean = extractKey(keyF.text.toString())
            if (clean == null) {
                toast("That does not look like a valid API key. Paste only the key.")
                return@setOnClickListener
            }
            val nm = nameF.text.toString().trim().ifEmpty { "Key " + (keys.size + 1) }
            if (existing == null) {
                keys.add(SavedKey(nm, clean))
                activeKey = keys.size - 1
            } else {
                existing.name = nm
                existing.value = clean
            }
            commitKeys()
            dlg.dismiss()
            done()
        }
    }

    private fun confirmDelete(i: Int, done: () -> Unit) {
        val k = keys.getOrNull(i) ?: return
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Delete \"" + k.name + "\"?")
            .setMessage("This removes the saved key from this phone.")
            .setPositiveButton("Delete") { _, _ ->
                keys.removeAt(i)
                if (i < activeKey) activeKey--
                if (activeKey >= keys.size) activeKey = keys.size - 1
                if (activeKey < 0) activeKey = 0
                commitKeys()
                done()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ providers
    private fun loadProvider(pos: Int) {
        cur = pos
        keys = loadKeys(pos)
        activeKey = prefs.getInt("akey_" + pos, 0)
        if (activeKey >= keys.size) activeKey = keys.size - 1
        if (activeKey < 0) activeKey = 0
        url.setText(prefs.getString("url_" + pos, urls[pos]))
        model.setText(prefs.getString("model_" + pos, suggestions[pos].firstOrNull() ?: ""))
        providerBtn.text = names[pos] + "   ▾"
        refreshKeyRow()
    }

    private fun pickProvider() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("AI provider")
            .setItems(names.toTypedArray()) { _, which ->
                saveAll()
                loadProvider(which)
                ApiStatus.reset()
                updateLive()
            }
            .show()
    }

    private fun pickModelDialog() {
        val list = suggestions[cur]
        if (list.isEmpty()) {
            toast("Type any model name")
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Suggested models")
            .setItems(list.toTypedArray()) { _, which ->
                model.setText(list[which])
                ApiStatus.reset()
                updateLive()
            }
            .show()
    }

    private fun saveAll() {
        persistKeys()
        prefs.edit()
            .putInt("provider", cur)
            .putString("url_" + cur, url.text.toString().trim())
            .putString("model_" + cur, model.text.toString().trim())
            .putInt("speed", speed)
            .putString("steps", steps.text.toString().trim())
            .putBoolean("vision", swVision.isChecked)
            .putBoolean("risky", swRisky.isChecked)
            .putString("extra", extra.text.toString())
            .putString("draft", cmd.text.toString())
            .apply()
    }

    private fun updateSpeed() {
        for (i in speedTabs.indices) {
            speedTabs[i].background = ripple(if (i == speed) ACCENT else FIELD)
        }
        speedDesc.text = when (speed) {
            0 -> "Fastest. Waits less for screens to load; may miss slow apps."
            1 -> "Balanced speed and reliability."
            else -> "Slowest. Waits longer for screens; best for slow phones or apps."
        }
    }

    // ------------------------------------------------------------------ recents
    private fun recents(): List<String> =
        (prefs.getString("recents", "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun addRecent(c: String) {
        val one = c.replace("\n", " ")
        val l = ArrayList<String>()
        l.add(one)
        for (r in recents()) if (r != one) l.add(r)
        prefs.edit().putString("recents", l.take(8).joinToString("\n")).apply()
        buildRecents()
    }

    private fun buildRecents() {
        recentsRow.removeAllViews()
        val all = ArrayList<String>()
        all.addAll(recents())
        for (e in examples) if (!all.contains(e)) all.add(e)
        for (s in all) {
            val t = label(if (s.length > 30) s.take(30) + "…" else s, 12.5f, TEXT)
            t.setPadding(dp(12), dp(7), dp(12), dp(7))
            t.background = ripple(FIELD, 16)
            t.isClickable = true
            t.setOnClickListener { cmd.setText(s); cmd.setSelection(cmd.text.length) }
            val p = lpw(WRAP, WRAP)
            p.rightMargin = dp(8)
            recentsRow.addView(t, p)
        }
    }

    // ------------------------------------------------------------------ status + log
    private fun refreshState() {
        val on = AgentService.instance != null
        val running = AgentService.running
        banner.visibility = if (on) View.GONE else View.VISIBLE
        if (!on) {
            chip.text = "● Accessibility off"
            chip.background = rounded(Color.parseColor("#6B4E16"), 14)
        } else if (running) {
            chip.text = "● Running"
            chip.background = rounded(Color.parseColor("#3B4BB8"), 14)
        } else {
            chip.text = "● Ready"
            chip.background = rounded(Color.parseColor("#1E7A4F"), 14)
        }
        runBtn.visibility = if (running) View.GONE else View.VISIBLE
        stopBtn.visibility = if (running) View.VISIBLE else View.GONE
    }

    // refreshed every 400 ms: API health, current phase, where the time goes, problems
    private fun updateLive() {
        when (ApiStatus.state) {
            1 -> {
                apiText.text = "● Active  ·  last " + fmtMs(ApiStatus.lastMs) + "  ·  avg " + fmtMs(ApiStatus.avg())
                apiText.setTextColor(GREEN)
            }
            2 -> {
                apiText.text = "● Inactive  ·  " + ApiStatus.detail
                apiText.setTextColor(RED)
            }
            else -> {
                apiText.text = "● Not tested yet"
                apiText.setTextColor(MUTED)
            }
        }

        val mn = model.text.toString().lowercase()
        modelHint.visibility = if (mn.contains("pro") || mn.contains("opus")) View.VISIBLE else View.GONE

        val running = AgentService.running
        val nowMs = System.currentTimeMillis()
        if (running) {
            phaseTv.text = "Step " + Live.step + "/" + Live.maxSteps + "  ·  " + Live.phase +
                " (" + fmtMs(nowMs - Live.phaseSince) + ")  ·  total " + fmtMs(nowMs - Live.startedAt)
        } else if (Live.startedAt > 0L && Live.endedAt > 0L) {
            phaseTv.text = "Last run: " + Live.step + " steps in " + fmtMs(Live.endedAt - Live.startedAt)
        } else {
            phaseTv.text = "Idle. Time spent per step will show here."
        }

        val ai = Live.aiMs
        val wt = Live.waitMs + Live.shotMs
        val ac = Live.actMs
        setW(segAi, ai)
        setW(segWait, wt)
        setW(segAct, ac)
        legAi.text = "■ AI " + fmtMs(ai)
        legWait.text = "■ Waiting " + fmtMs(wt)
        legAct.text = "■ Actions " + fmtMs(ac)

        if (Live.fails > 0 || Live.warns > 0) {
            problemTv.visibility = View.VISIBLE
            problemTv.text = "⚠ " + Live.fails + " failed  ·  " + Live.warns + " warnings" +
                (if (Live.lastProblem.isNotEmpty()) "\nLast: " + Live.lastProblem else "")
        } else {
            problemTv.visibility = View.GONE
        }
    }

    private fun prefix(kind: Int): String = when (kind) {
        K_STEP -> ""
        K_ACT -> "  -> "
        K_OK -> "[OK] "
        K_ERR -> "[ERROR] "
        K_WARN -> "[WARN] "
        K_TIME -> "  (time) "
        else -> ""
    }

    private fun copyLog() {
        val sb = StringBuilder()
        sb.append("Phone Agent v3.2 | ").append(names[cur]).append(" | model ").append(model.text.toString().trim())
            .append(" | speed ").append(speed).append(" | vision ").append(swVision.isChecked)
            .append(" | API state ").append(ApiStatus.state).append(" ").append(ApiStatus.detail).append("\n")
        synchronized(AgentService.entries) {
            for (e in AgentService.entries) sb.append(prefix(e.kind)).append(e.text).append("\n")
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("agent log", sb.toString()))
        toast("Log copied. Paste it in the chat.")
    }

    private fun addEntry(e: LogEntry) {
        emptyHint.visibility = View.GONE
        val t = TextView(this)
        t.textSize = 13.5f
        t.setPadding(0, dp(3), 0, dp(3))
        when (e.kind) {
            K_STEP -> {
                t.setTextColor(TEXT)
                t.text = e.text
            }
            K_ACT -> {
                t.setTextColor(ACCENT)
                t.typeface = Typeface.MONOSPACE
                t.text = "  → " + e.text
            }
            K_OK -> {
                t.setTextColor(GREEN)
                t.text = "✓ " + e.text
            }
            K_ERR -> {
                t.setTextColor(RED)
                t.text = "✖ " + e.text
            }
            K_WARN -> {
                t.setTextColor(AMBER)
                t.text = "⚠ " + e.text
            }
            K_TIME -> {
                t.setTextColor(MUTED)
                t.textSize = 11.5f
                t.typeface = Typeface.MONOSPACE
                t.text = "  ⏱ " + e.text
            }
            else -> {
                t.setTextColor(MUTED)
                t.text = e.text
            }
        }
        logBox.addView(t)
    }

    override fun onResume() {
        super.onResume()
        logBox.removeAllViews()
        val copy = synchronized(AgentService.entries) { ArrayList(AgentService.entries) }
        emptyHint.visibility = if (copy.isEmpty()) View.VISIBLE else View.GONE
        for (e in copy) addEntry(e)
        AgentService.logger = { e -> runOnUiThread { addEntry(e); refreshState() } }
        refreshState()
        tick.post(ticker)
    }

    override fun onPause() {
        AgentService.logger = null
        tick.removeCallbacks(ticker)
        saveAll()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) cmd.setText(t)
        }
    }
}
