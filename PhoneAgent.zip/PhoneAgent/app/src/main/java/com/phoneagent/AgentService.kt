package com.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

private const val R_OK = 0
private const val R_FAIL = 1
private const val R_END = 2

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        @Volatile var running = false
        @Volatile var logger: ((LogEntry) -> Unit)? = null
        val entries = ArrayList<LogEntry>()

        private val RISKY = Regex(
            "pay|purchase|buy now|place order|checkout|delete|transfer|send money|পেমেন্ট|কিনুন|ডিলিট|মুছে",
            RegexOption.IGNORE_CASE
        )

        fun clearLog() {
            synchronized(entries) { entries.clear() }
        }
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()
    private var runId = 0
    private var overlay: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val shotExec = Executors.newSingleThreadExecutor()
    private var shotScale = 1f
    private var shotW = 0
    private var shotH = 0
    @Volatile private var curPkg = ""
    private var failWhy = ""

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        running = false
        hideOverlay()
        return super.onUnbind(intent)
    }

    // Emergency stop: Volume Down while the agent is running
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (running && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                running = false
                log(K_INFO, "Stopped (Volume Down)")
            }
            return true
        }
        return false
    }

    private fun log(kind: Int, msg: String) {
        val e = LogEntry(kind, msg)
        synchronized(entries) { entries.add(e) }
        logger?.invoke(e)
    }

    private fun warn(msg: String) {
        Live.warns++
        log(K_WARN, msg)
    }

    private fun now(): Long = System.currentTimeMillis()

    private fun toast(s: String) {
        ui.post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun alive(id: Int) = running && id == runId

    // ---------------------------------------------------------------- floating stop bubble
    private fun showOverlay() {
        ui.post {
            if (overlay != null) return@post
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val tv = TextView(this)
                tv.text = "■  Stop"
                tv.setTextColor(Color.WHITE)
                tv.textSize = 13f
                tv.setPadding(dp(14), dp(8), dp(14), dp(8))
                val bg = GradientDrawable()
                bg.cornerRadius = dp(22).toFloat()
                bg.setColor(Color.parseColor("#E6E5484D"))
                tv.background = bg
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
                lp.x = dp(6)
                lp.y = 0
                tv.setOnTouchListener(object : View.OnTouchListener {
                    var sx = 0f
                    var sy = 0f
                    var ox = 0
                    var oy = 0
                    var moved = false
                    override fun onTouch(v: View, e: MotionEvent): Boolean {
                        when (e.action) {
                            MotionEvent.ACTION_DOWN -> {
                                sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val dx = (e.rawX - sx).toInt()
                                val dy = (e.rawY - sy).toInt()
                                if (abs(dx) > 12 || abs(dy) > 12) moved = true
                                lp.x = ox - dx
                                lp.y = oy + dy
                                try { wm.updateViewLayout(tv, lp) } catch (ex: Exception) {}
                            }
                            MotionEvent.ACTION_UP -> {
                                if (!moved) {
                                    running = false
                                    log(K_INFO, "Stopped (Stop button)")
                                }
                            }
                        }
                        return true
                    }
                })
                wm.addView(tv, lp)
                overlay = tv
            } catch (e: Exception) {
            }
        }
    }

    private fun updateOverlay(text: String) {
        ui.post { overlay?.text = text }
    }

    private fun hideOverlay() {
        ui.post {
            val o = overlay
            if (o != null) {
                try {
                    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                    wm.removeView(o)
                } catch (e: Exception) {
                }
            }
            overlay = null
        }
    }

    // ---------------------------------------------------------------- main loop
    fun start(task: String, cfg: AgentConfig) {
        if (running) { log(K_INFO, "Already running"); return }
        running = true
        runId++
        val id = runId
        Thread {
            try {
                runLoop(task, cfg, id)
            } catch (e: Exception) {
                Live.fails++
                Live.lastProblem = "Crash: " + e.message
                log(K_ERR, "Unexpected error: " + e.javaClass.simpleName + ": " + e.message)
            } finally {
                if (id == runId) running = false
                Claude.onNote = null
                Live.endedAt = now()
                Live.markPhase("Idle")
                hideOverlay()
                summary()
                log(K_INFO, "— finished —")
            }
        }.start()
    }

    private fun summary() {
        if (Live.step == 0) return
        val total = (Live.endedAt - Live.startedAt).coerceAtLeast(1L)
        val ai = Live.aiMs
        val wt = Live.waitMs
        val ac = Live.actMs
        log(
            K_INFO,
            "Summary: " + Live.step + " steps in " + fmtMs(total) +
                " | AI " + fmtMs(ai) + " (" + (ai * 100 / total) + "%)" +
                " | screen wait " + fmtMs(wt) + " (" + (wt * 100 / total) + "%)" +
                " | actions " + fmtMs(ac) +
                " | failed actions " + Live.fails
        )
        if (ai * 100 / total >= 60) {
            log(K_WARN, "Slow because of the AI: average " + fmtMs(ApiStatus.avg()) + " per call. Use a faster model (Gemini Flash, Claude Haiku, Groq) or check your internet.")
        } else if (wt * 100 / total >= 40) {
            log(K_WARN, "Slow because of waiting for screens to settle. Set Speed to Fast in Advanced.")
        }
        if (Live.fails > 0) log(K_WARN, "Last problem: " + Live.lastProblem)
    }

    private fun runLoop(task: String, cfg: AgentConfig, id: Int) {
        val history = ArrayList<String>()
        val apps = installedApps()
        val sp = cfg.speed.coerceIn(0, 2)
        val minWait = longArrayOf(250, 600, 1100)[sp]
        val maxWait = longArrayOf(2500, 4000, 6000)[sp]
        val label = cfg.provider + " · " + cfg.model

        Live.reset(cfg.maxSteps)
        Claude.onNote = { n -> warn(n) }
        showOverlay()
        toast("Agent started. Volume Down or the red Stop = stop")
        history.add("start: you are inside the Phone Agent control app. Ignore it. Begin with open_app, open_url or home.")
        Live.markPhase("Reading screen")
        var screen = readScreen()

        var lastSig = 0
        var sameCount = 0
        var lastKey = ""
        var repeat = 0
        var slowWarned = false
        var warnedPkg = ""

        for (step in 1..cfg.maxSteps) {
            if (!alive(id)) return
            Live.step = step
            updateOverlay("■  Stop  " + step + "/" + cfg.maxSteps)

            if (nodes.size <= 2 && curPkg.isNotEmpty() && curPkg != packageName && curPkg != warnedPkg) {
                warnedPkg = curPkg
                warn("Only " + nodes.size + " readable elements in " + curPkg + ". This app may hide its UI from accessibility. Turn on 'Use screenshots' in Advanced (needs a vision model).")
            }

            var img: String? = null
            var tShot = 0L
            if (cfg.vision) {
                Live.markPhase("Taking screenshot")
                val t = now()
                img = screenshotB64()
                tShot = now() - t
                if (img == null) warn("Screenshot failed (needs Android 11+). Continuing with text only.")
            }
            if (img == null) {
                shotScale = 1f
                shotW = 0
                shotH = 0
            }

            val lastH = history.lastOrNull() ?: ""
            val sendApps = step <= 2 || (lastH.contains("open_app") && lastH.contains("FAILED"))

            Live.markPhase("Waiting for AI")
            val tAi0 = now()
            val reply = try {
                Claude.decide(cfg, task, if (sendApps) apps else "", history, screen, img, shotW, shotH)
            } catch (e: Exception) {
                var why = Claude.explain(e)
                if (cfg.vision && why.contains("HTTP 400")) {
                    why = why + " (Screenshots are ON: this model may not accept images. Turn off 'Use screenshots' in Advanced.)"
                }
                ApiStatus.fail(why, label)
                Live.fails++
                Live.lastProblem = "AI error: " + why
                log(K_ERR, "AI error: " + why)
                return
            }
            val tAi = now() - tAi0
            ApiStatus.ok(tAi, label)
            Live.aiMs += tAi
            Live.shotMs += tShot
            if (!alive(id)) return
            log(K_STEP, "" + step + ". " + reply.thought)

            var tAct = 0L
            var failed = false
            for ((i, a) in reply.actions.withIndex()) {
                if (!alive(id)) return
                Live.markPhase("Doing: " + a.optString("action"))
                log(K_ACT, describe(a))
                val t = now()
                failWhy = ""
                val r = exec(a, cfg)
                tAct += now() - t
                val key = a.optString("action") + " " + brief(a)
                history.add(
                    "step " + step + ": " + key + " -> " +
                        (if (r == R_FAIL) "FAILED (" + failWhy + ")" else "ok")
                )
                if (r == R_END) return
                if (r == R_FAIL) {
                    Live.fails++
                    Live.lastProblem = a.optString("action") + " failed: " + failWhy
                    log(K_WARN, "Failed: " + failWhy)
                    failed = true
                    break
                }
                if (key == lastKey) repeat++ else repeat = 0
                lastKey = key
                if (i < reply.actions.size - 1) Thread.sleep(300)
            }
            Live.actMs += tAct

            if (repeat >= 2) {
                warn("The same action was repeated " + (repeat + 1) + " times. The agent may be stuck in a loop.")
                history.add("NOTE: you repeated the same action several times without progress. Do something different.")
                repeat = 0
            }

            Live.markPhase("Waiting for screen")
            val tW0 = now()
            screen = settle(minWait, maxWait)
            val tW = now() - tW0
            Live.waitMs += tW

            val sig = screen.hashCode()
            if (!failed) {
                if (sig == lastSig) sameCount++ else sameCount = 0
            }
            lastSig = sig
            if (sameCount >= 2) {
                warn("The screen did not change after " + sameCount + " steps. The app may ignore the agent's taps, or the agent is hitting the wrong element.")
                history.add("NOTE: the screen did not change after your last " + sameCount + " actions. Try a different element, tap_xy, scrolling, or open_url.")
                sameCount = 0
            }

            log(
                K_TIME,
                "AI " + fmtMs(tAi) + " · actions " + fmtMs(tAct) + " · screen wait " + fmtMs(tW) +
                    (if (tShot > 0) " · screenshot " + fmtMs(tShot) else "")
            )
            if (tAi > 6000 && !slowWarned) {
                slowWarned = true
                warn("The AI took " + fmtMs(tAi) + " for one step. This is the main cause of slowness. Use a faster model (Gemini Flash, Claude Haiku, Groq) or check your internet.")
            }
            if (tW >= maxWait) {
                warn("The screen kept changing for " + fmtMs(tW) + " (loading or animation). Moved on anyway.")
            }
        }
        log(K_ERR, "Step limit reached (" + cfg.maxSteps + "). Increase Max steps in Advanced if the task needs more.")
    }

    // wait until the screen stops changing; returns the latest screen text
    private fun settle(minMs: Long, maxMs: Long): String {
        Thread.sleep(minMs)
        var waited = minMs
        var cur = readScreen()
        while (waited < maxMs && running) {
            Thread.sleep(200)
            waited += 200
            val next = readScreen()
            if (next == cur) return next
            cur = next
        }
        return cur
    }

    private fun res(ok: Boolean, why: String = "Android rejected the action"): Int {
        if (ok) return R_OK
        failWhy = why
        return R_FAIL
    }

    private fun fail(why: String): Int {
        failWhy = why
        return R_FAIL
    }

    private fun node(a: JSONObject): AccessibilityNodeInfo? = nodes.getOrNull(a.optInt("id", -1))

    private fun exec(a: JSONObject, cfg: AgentConfig): Int {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val name = a.optString("action")
        when (name) {
            "tap" -> {
                val n = node(a) ?: return fail("element #" + a.optInt("id", -1) + " is not on the current screen")
                val label = ((n.text ?: "").toString() + " " + (n.contentDescription ?: "")).trim()
                if (!cfg.allowRisky && RISKY.containsMatchIn(label)) {
                    log(K_ERR, "Needs your OK to tap \"" + label + "\". Turn on 'Allow risky taps' and run again.")
                    return R_END
                }
                return res(tap(n), "the element is not clickable and the tap gesture was blocked")
            }
            "tap_xy" -> {
                if (!a.has("x") || !a.has("y")) return fail("tap_xy needs x and y")
                val x = a.optDouble("x", -1.0).toFloat() * shotScale
                val y = a.optDouble("y", -1.0).toFloat() * shotScale
                if (x < 0f || y < 0f) return fail("tap_xy coordinates are invalid")
                return res(gesture(x, y, x, y, 60), "Android rejected the tap gesture (app may block input)")
            }
            "long_press" -> {
                val n = node(a) ?: return fail("element #" + a.optInt("id", -1) + " is not on the current screen")
                val r = Rect()
                n.getBoundsInScreen(r)
                val cx = r.centerX().toFloat()
                val cy = r.centerY().toFloat()
                return res(gesture(cx, cy, cx, cy, 800), "long press gesture rejected")
            }
            "type" -> {
                val n = node(a) ?: return fail("input #" + a.optInt("id", -1) + " is not on the current screen")
                val text = a.optString("text")
                val args = Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return R_OK
                try {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("agent", text))
                    n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    if (n.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return R_OK
                } catch (e: Exception) {
                }
                return fail("the field refused text input (set-text and paste both failed)")
            }
            "enter" -> {
                if (Build.VERSION.SDK_INT < 30) return fail("Enter key needs Android 11+. Tap the search/submit button instead")
                val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    ?: return fail("no focused input field to press Enter on")
                return res(
                    f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id),
                    "the field ignored the Enter key. Tap the search button instead"
                )
            }
            "scroll_down" -> return res(gesture(w / 2, h * 0.72f, w / 2, h * 0.28f, 300), "scroll gesture rejected")
            "scroll_up" -> return res(gesture(w / 2, h * 0.28f, w / 2, h * 0.72f, 300), "scroll gesture rejected")
            "swipe_left" -> return res(gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 280), "swipe gesture rejected")
            "swipe_right" -> return res(gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 280), "swipe gesture rejected")
            "back" -> return res(performGlobalAction(GLOBAL_ACTION_BACK), "system Back rejected")
            "home" -> return res(performGlobalAction(GLOBAL_ACTION_HOME), "system Home rejected")
            "recents" -> return res(performGlobalAction(GLOBAL_ACTION_RECENTS), "system Recents rejected")
            "notifications" -> return res(performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS), "system Notifications rejected")
            "open_app" -> return res(openApp(a.optString("app")), "app '" + a.optString("app") + "' was not found or could not be opened")
            "open_url" -> return res(openUrl(a.optString("url")), "no app can open this link, or the link is empty")
            "wait" -> {
                Thread.sleep(1200)
                return R_OK
            }
            "done" -> {
                log(K_OK, a.optString("message"))
                return R_END
            }
            "ask_user" -> {
                log(K_INFO, "? " + a.optString("message"))
                return R_END
            }
            else -> return fail("unknown action '" + name + "'")
        }
    }

    private fun brief(a: JSONObject): String {
        val sb = StringBuilder()
        if (a.has("id")) sb.append("id=").append(a.optInt("id")).append(" ")
        if (a.optString("text").isNotEmpty()) sb.append("text=").append(a.optString("text")).append(" ")
        if (a.optString("app").isNotEmpty()) sb.append("app=").append(a.optString("app")).append(" ")
        if (a.optString("url").isNotEmpty()) sb.append("url=").append(a.optString("url")).append(" ")
        if (a.has("x") && a.has("y")) sb.append("x=").append(a.optInt("x")).append(" y=").append(a.optInt("y"))
        return sb.toString().trim()
    }

    private fun describe(a: JSONObject): String {
        val name = a.optString("action")
        val n = nodes.getOrNull(a.optInt("id", -1))
        var label = ""
        if (n != null) {
            label = (n.text ?: "").toString()
            if (label.isBlank()) label = (n.contentDescription ?: "").toString()
            label = label.take(30)
        }
        return name + (if (label.isNotBlank()) " \"" + label + "\"" else "") + " " + brief(a)
    }

    // ---------------------------------------------------------------- apps / urls
    private fun launcherApps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
    }

    private fun installedApps(): String =
        launcherApps().map { it.first }.distinct().sorted().take(120).joinToString(", ")

    private fun openApp(name: String): Boolean {
        return try {
            val all = launcherApps()
            val m = all.firstOrNull { it.first.equals(name, true) }
                ?: all.firstOrNull { it.first.contains(name, true) }
                ?: return false
            val intent = packageManager.getLaunchIntentForPackage(m.second) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openUrl(url: String): Boolean {
        if (url.isBlank()) return false
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------------------------------------------------------------- screen reading
    private fun readScreen(): String {
        val root = rootInActiveWindow
        if (root == null) {
            nodes = emptyList()
            curPkg = ""
            return "(screen not readable right now)"
        }
        curPkg = root.packageName?.toString() ?: ""
        if (curPkg == packageName) {
            nodes = emptyList()
            return "App: Phone Agent (the control app itself; use open_app / open_url / home)"
        }
        val dm = resources.displayMetrics
        val list = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: " + curPkg + " | Screen: " + dm.widthPixels + "x" + dm.heightPixels + " px\n")

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || list.size >= 100) return
            if (!n.isVisibleToUser) return
            val text = (n.text ?: "").toString().take(50).replace("\"", "'").replace("\n", " ")
            val desc = (n.contentDescription ?: "").toString().take(50).replace("\"", "'").replace("\n", " ")
            val useful = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable ||
                text.isNotBlank() || desc.isNotBlank()
            if (useful) {
                val idx = list.size
                list.add(n)
                val cls = n.className?.toString()?.substringAfterLast('.') ?: ""
                val r = Rect()
                n.getBoundsInScreen(r)
                sb.append("[").append(idx).append("] ").append(cls)
                if (n.isPassword) {
                    sb.append(" (password field)")
                } else if (text.isNotBlank()) {
                    sb.append(" \"").append(text).append("\"")
                }
                if (desc.isNotBlank()) sb.append(" desc=\"").append(desc).append("\"")
                if (n.isClickable) sb.append(" [tap]")
                if (n.isEditable) sb.append(" [input]")
                if (n.isScrollable) sb.append(" [scroll]")
                if (n.isChecked) sb.append(" [checked]")
                sb.append(" @").append(r.centerX()).append(",").append(r.centerY())
                sb.append("\n")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }

        walk(root)
        nodes = list
        return sb.toString()
    }

    private fun screenshotB64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                shotExec,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = r.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            if (hw != null) {
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                hb.close()
                                if (soft != null) {
                                    val sc = 900f / maxOf(soft.width, soft.height)
                                    val bmp = if (sc < 1f) {
                                        Bitmap.createScaledBitmap(
                                            soft, (soft.width * sc).toInt(), (soft.height * sc).toInt(), true
                                        )
                                    } else soft
                                    shotW = bmp.width
                                    shotH = bmp.height
                                    shotScale = soft.width.toFloat() / bmp.width
                                    val bo = ByteArrayOutputStream()
                                    bmp.compress(Bitmap.CompressFormat.JPEG, 60, bo)
                                    out = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                                }
                            }
                        } catch (e: Exception) {
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        latch.countDown()
                    }
                }
            )
            latch.await(4, TimeUnit.SECONDS)
        } catch (e: Exception) {
        }
        return out
    }

    // ---------------------------------------------------------------- gestures
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var hops = 0
        while (c != null && hops < 5) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            hops++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms))
            .build()
        return dispatchGesture(g, null, null)
    }
}
