plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.phoneagent"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.phoneagent"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "3.2"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("phoneagent.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
